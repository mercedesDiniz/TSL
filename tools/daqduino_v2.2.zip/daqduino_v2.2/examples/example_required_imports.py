#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jan 15 18:11:28 2020

@author:
    Dr. Prof. Antonio da Silva Silveira
    E-mail: asilveira@ufpa.br
    Laboratory of Control and Systems (LACOS.ufpa.br)
    Federal University of Pará (UFPA.br)

Title:
    Data Acquisition and Least-Squares parametric estimation.

Description:
    - Use of the DaqDuino (for Python) to register I/O data of a servomotor
    device;
    - Run a ARX221 parametric estimation by non-recursive Least-Squares.

"""

#%% Required Python modules
import numpy as np
import matplotlib.pyplot as plt
from control.matlab import *
import daqduino
# matplotlib inline/auto <- type this to show figures inside/outside the Console 

#%% Setting-up some required variables
Ts = 0.05; # sampling-time in seconds

#%% Registering input and output data from the servomotor
# Generating an input discrete sequence to excite the process
u=np.zeros(100,float); # defining and creating variable space
u[0:10]=np.zeros(10,float);
u[10:30]=1*np.ones(20,float); # step 1V
u[30:50]=2*np.ones(20,float); # step 2V
u[50:70]=3*np.ones(20,float); # step 3V
u = np.resize(u,70);
N = np.size(u); # number of iterations

# DAQ loop with DaqDuino
y = np.zeros(N,float); # reserving variable space

daqduino.start('/dev/ttyUSB0'); # Connect to DAQ
for k in range(N):
    y[k] = daqduino.read(); # A-D
    daqduino.write(u[k],Ts);
    print('Samples remaining to process: ' + str(N-k));
daqduino.end(); # Disconnect from DAQ

# Ploting DAQ registered I/O
t = np.arange(0,N*Ts,Ts); # Generating a time vector for the plots
plt.figure(); # New figure window
plt.plot(t.T,u.T,'k',t.T,y.T,'b');
plt.title('Servomotor response to a sequence of steps.');
plt.ylabel('Amplitude [V]');
plt.xlabel('Time [s]');
plt.show(); # force-show figure

#%% Non-recursive Least-Squares ARX221 parameters estimation
PHI = np.zeros([N,4],float); # Matrix of regressors definition
for k in range(N):
    PHI[k,:] = [ -y[k-1], -y[k-2], u[k-1], u[k-2] ];
    
P = np.linalg.inv(np.dot(PHI.T,PHI)); # Estimation Error Covariance Matrix
Y = y.T; # Vector of observations
THETA = np.dot( np.dot(P,PHI.T) , Y ); # Vector of estimated parameters

# Estimated ARX221 parameters A(z)y(k)=B(z)u(k-1)+v(k)
a1 = THETA[0]; a2 = THETA[1];
b0 = THETA[2]; b1 = THETA[3];

Gz = tf([0, b0, b1],[1, a1, a2],Ts);

#%% Identified system analysis
ysim = lsim(Gz, u, t); # Linear simulation of G(z) using u sequence
plt.plot(t.T,ysim[0],'r');
plt.legend(['Input','Output','Model Sim.']);

fig2 = plt.figure(2);
w = np.logspace(-2,2,100);
bode(Gz, w, Hz=False);
plt.title('Frequency response analysis of the estimated model.');
plt.show();


























