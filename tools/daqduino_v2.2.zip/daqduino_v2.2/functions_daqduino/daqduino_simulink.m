function [y]=daqduino_simulink(input),
    global y;
    u=input(1);
    Ts=input(2);
    y=daqduino_read;
    daqduino_write(u,Ts);
    