#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jan 15 16:25:02 2020

@author: 
    Dr. Prof. Antonio da Silva Silveira
    E-mail: asilveira@ufpa.br
    Laboratory of Control and Systems (LACOS.ufpa.br)
    Federal University of Pará (UFPA.br)

DaqDuino (for Python):
    Arduino-based Data Acquisition Device for Computer-controlled
    systems practices.

Description:
    Use the Arduino board as a single-shot data aqcuisition (DAQ)
    device for computer-controlled systems practices (Digital 
    Control Theory). This package comes with four main functions:
    daqduino_start(), daqduino_end(), daqduino_write(),
    daqduino_read(). For more information on this project visit:
    www.mathworks.com/matlabcentral/fileexchange/50784-daqduino

Requirements:
    Modules serial and time.
"""

import serial;
import time;

def start(CommPort):
    global daq;
    daq = serial.Serial(CommPort,115200,timeout=0.005);
    time.sleep(2);
    daq.write(b'0.0'); # Set 0V at D-A pin
    time.sleep(1);
    
    text = """
    -----------------------------------------------------------------
                LACOS DaqDuino (2013-2021).
    -----------------------------------------------------------------
    DaqDuino (for Python):
        Arduino-based Data Acquisition Device for
        Computer-controlled systems practices.
    
    Author: 
        Dr. Prof. Antonio da Silva Silveira
        E-mail: asilveira@ufpa.br
        Laboratory of Control and Systems (LACOS.ufpa.br)
        Federal University of Pará (UFPA.br)
        
    Description:
        Use the Arduino board as a single-shot data aqcuisition (DAQ)
        device for computer-controlled systems practices (Digital 
        Control Theory). This package comes with four main functions:
        daqduino_start(), daqduino_end(), daqduino_write(),
        daqduino_read(). For more information on this project visit:
        www.mathworks.com/matlabcentral/fileexchange/50784-daqduino
        
    Requirements:
        Modules serial and time.
    -----------------------------------------------------------------
    
    ----------------------
    DaqDuino connected!
    ----------------------
    """;
    print(text);
    
def read():
    """
    Analog to digital conversion in range of 0V to 5V from the Arduino
    A-D pin. This function returns a float.
    """
    global daq;
    return float(daq.readall().decode());

def write(u,Ts): # Control Sample and Sampling-time (s)
    """
    Writes the float u, in the range of 0V to 5V, at the D-A pin, and holds
    for Ts seconds.
    
    Remark: The minimum Ts value is 0.04 seconds.
    """
    global daq;
    daq.write(str(u).encode());
    time.sleep(Ts);
    
def end():
    """
    Sets zero Volts at the D-A pin and closes the serial connection
    to the Arduino board.
    """
    global daq;
    daq.write(b'0.0'); # Set 0V at D-A pin
    daq.close();
    print('DaqDuino disconnected!')
    
    
    
    
    
    
    
    
    
    
    
    
    